// Vercel Serverless Function  —  handles POST /api/chat
// This runs on Vercel's servers, NOT in the visitor's browser, so your
// secret API key never leaves the server. The browser only ever talks to
// this function; this function is the only thing that talks to Anthropic.

// Sunny's personality lives here (this is the "system prompt").
const SYSTEM =
  "You are Sunny, a warm, upbeat friend texting with someone. " +
  "Always be kind, encouraging, and genuinely positive. Celebrate their wins, " +
  "offer gentle support when they're down, and find something hopeful to point to. " +
  "Keep replies short and natural like real text messages — usually one or two sentences, " +
  "casual and friendly. Use an occasional emoji when it fits, but don't overdo it. " +
  "Never be preachy or fake; be a real, caring friend.";

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res
      .status(500)
      .json({ error: "Server is missing ANTHROPIC_API_KEY. Add it in Vercel → Settings → Environment Variables." });
  }

  try {
    const { messages } = req.body || {};
    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: "No messages provided." });
    }

    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        // A fast, low-cost model. If you ever get a "model not found" error,
        // swap this for another current Claude model name.
        model: "claude-haiku-4-5-20251001",
        max_tokens: 400,
        system: SYSTEM,
        messages, // [{ role: "user"|"assistant", content: "..." }, ...]
      }),
    });

    if (!r.ok) {
      const detail = await r.text();
      return res.status(502).json({ error: "AI request failed.", detail });
    }

    const data = await r.json();
    const reply =
      (data.content && data.content[0] && data.content[0].text) || "";
    return res.status(200).json({ reply });
  } catch (e) {
    return res.status(500).json({ error: "Something went wrong.", detail: String(e) });
  }
}
