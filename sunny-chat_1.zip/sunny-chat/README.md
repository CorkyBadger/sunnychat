# Sunny Texts 🌻

An iMessage-style chat with a warm, encouraging AI, hosted on Vercel.

## What's in here

- `index.html` — the chat page people see (runs in the browser)
- `api/chat.js` — the secret-keeping backend function (runs on Vercel's servers, holds your API key)

## How to put it online

1. Put this whole folder into a GitHub repo (keep the `api` folder exactly where it is).
2. In Vercel: Add New → Project → Import your repo.
3. Before deploying, add an Environment Variable:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** your key from https://console.anthropic.com (Settings → API Keys)
4. Click Deploy. Done!

## Important

- Never put your API key inside the code or in a public place. It only goes in
  Vercel's Environment Variables box, where it stays private.
- Using the AI costs a small amount per message (pay-as-you-go via Anthropic).

## Change Sunny's personality

Edit the `SYSTEM` text near the top of `api/chat.js`, then push the change to
GitHub — Vercel redeploys automatically.
